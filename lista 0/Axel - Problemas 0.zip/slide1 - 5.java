public class Main {

    public static void main(String[] args) {

        //Criar um programa que liste a soma dos números de 1 a 50;
        int x = 0;

        for(int i=1; i<51; i++) {
            x += i;
        }

        System.out.print(x);
    }
}
